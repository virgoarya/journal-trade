1:"$Sreact.fragment"
2:I[90484,[],"ViewportBoundary"]
3:I[90484,[],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[86869,[],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Hunter Trades Journal"}],["$","meta","1",{"name":"description","content":"Exclusive trading journal for Hunter Trades members"}],["$","link","2",{"rel":"icon","href":"/icon.png?b51db8d0b700c599","type":"image/png","sizes":"500x500"}],["$","$L5","3",{}]]}]}]}],null]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"aXJJbW4TTvWGvYNUG7Veo"}
