1:"$Sreact.fragment"
2:I[42593,["6609","static/chunks/6609-efa937991564888c.js","7177","static/chunks/app/layout-52a3c9f727c3a803.js"],""]
3:I[62902,["6609","static/chunks/6609-efa937991564888c.js","7177","static/chunks/app/layout-52a3c9f727c3a803.js"],"GuidanceProvider"]
4:I[57121,[],""]
5:I[74581,[],""]
6:I[27830,["6609","static/chunks/6609-efa937991564888c.js","7177","static/chunks/app/layout-52a3c9f727c3a803.js"],"OtaUpdaterModal"]
7:I[66609,["6609","static/chunks/6609-efa937991564888c.js","7177","static/chunks/app/layout-52a3c9f727c3a803.js"],"Toaster"]
:HL["/_next/static/css/d5cf937dbc4113ca.css","style"]
:HL["/_next/static/css/128ec261a1d3e516.css","style"]
:HL["https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap","style"]
0:{"rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/d5cf937dbc4113ca.css","precedence":"next"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/css/128ec261a1d3e516.css","precedence":"next"}]],["$","html",null,{"lang":"en","className":"__variable_d8ebd1 __variable_4dc837 h-full antialiased","suppressHydrationWarning":true,"children":[["$","head",null,{"children":["$","link",null,{"href":"https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap","rel":"stylesheet"}]}],["$","body",null,{"className":"min-h-full flex flex-col font-sans mb-0 relative","suppressHydrationWarning":true,"children":[["$","$L2",null,{"src":"https://app.sandbox.midtrans.com/snap/snap.js","strategy":"afterInteractive"}],["$","div",null,{"className":"fixed top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-accent-gold/10 blur-[120px] pointer-events-none -z-10"}],["$","div",null,{"className":"fixed bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-accent-gold/5 blur-[100px] pointer-events-none -z-10"}],["$","$L3",null,{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]}],["$","$L6",null,{}],["$","$L7",null,{"position":"top-right","richColors":true}]]}]]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"DzPAwhiX_5qVEH2WPwsiT"}
