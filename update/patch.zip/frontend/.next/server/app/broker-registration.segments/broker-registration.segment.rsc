1:"$Sreact.fragment"
2:I[78616,[],"ClientSegmentRoot"]
3:I[46939,["8251","static/chunks/8251-a4c046fd5e43278e.js","5791","static/chunks/app/broker-registration/layout-c903f063e79d7319.js"],"default"]
4:I[57121,[],""]
5:I[74581,[],""]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"Component":"$3","slots":{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]},"serverProvidedParams":{"params":{},"promises":["$@6"]}}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"DzPAwhiX_5qVEH2WPwsiT"}
6:"$0:rsc:props:children:1:props:serverProvidedParams:params"
