1:"$Sreact.fragment"
2:I[78616,[],"ClientSegmentRoot"]
3:I[80927,["697","static/chunks/697-60c4470f36dfab4b.js","1176","static/chunks/1176-aef2d2f0995e2842.js","371","static/chunks/371-c7bf60ac43157336.js","8707","static/chunks/app/(dashboard)/macro-terminal/layout-f8e886f8b7eeb953.js"],"default"]
4:I[57121,[],""]
5:I[74581,[],""]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"Component":"$3","slots":{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]},"serverProvidedParams":{"params":{},"promises":["$@6"]}}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"RPhYMPrwlOD-pS95xkdAG"}
6:"$0:rsc:props:children:1:props:serverProvidedParams:params"
